"""Packaged assets (prompts, policies) shipped with Evanesco."""

from importlib import resources

__all__ = ["resources"]
